# AGIFCore Project Rules

This override applies to everything under `projects/agifcore_master/`.

Read these files before any work:

1. `PROJECT_README.md`
2. `DECISIONS.md`
3. `CHANGELOG.md`
4. `01_plan/MASTER_PLAN.md`
5. `02_requirements/ROLE_AUTHORITY_RULES.md`
6. `02_requirements/EXECUTION_CHAIN_OF_COMMAND.md`
7. `02_requirements/FOLDER_OWNERSHIP_POLICY.md`
8. `02_requirements/MODEL_TIER_POLICY.md`
9. `00_admin/MODEL_MANIFEST.md`
10. `00_admin/TASK_CARD_TEMPLATE.md`
11. `00_admin/TOOL_PERMISSION_MATRIX.md`
12. `00_admin/BRANCH_AND_WORKTREE_POLICY.md`
13. `00_admin/ESCALATION_AND_FREEZE_RULES.md`
14. `01_plan/VALIDATION_PROTOCOL.md`

Rules:

- `01_plan/MASTER_PLAN.md` is frozen until the user explicitly approves a revision.
- Every task must align to the frozen master plan and the active phase plan.
- Every implementation, audit, merge, or validation pass must reference a frozen task card.
- Every phase closes only after a user-reviewed demo and explicit user approval.
- AGIFCore uses a governed build machine, not a generic manager/worker chain.
- Program Governor is the ultimate agent authority below the user.
- Specialized planning, build, test, audit, merge, validation, and release roles must follow the frozen role manifest.
- Build agents are outside the AGIFCore runtime and may never be treated as runtime truth.
- No agent may both write and validate the same artifact.
- The same model family does not mean the same agent. Build Pod Lead, Merge Arbiter, and Validation Agent must be separate agents, sessions, or threads.
- Tool permissions, branch/worktree isolation, model use, and escalation behavior must follow the frozen admin control files.
- Meta & Growth Pod is a danger zone and always gets extra audit and stronger governor review.
- Program Governor must independently inspect code, rerun checks, and verify demos. Report text alone is not enough.
- Program Governor is the only role that may ask the user for final phase review.
- One active build pod is the default unless the governor explicitly authorizes more parallel build work.
